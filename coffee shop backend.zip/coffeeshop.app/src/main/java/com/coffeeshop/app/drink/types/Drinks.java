package com.coffeeshop.app.drink.types;

public interface Drinks {
	int getId();
}
